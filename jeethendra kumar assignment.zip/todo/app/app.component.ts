import { Component, ɵsetCurrentInjector } from '@angular/core';
import { FormsModule} from '@angular/forms'
//import { AppComponent } from './app.component';

import {FormControl } from '@angular/forms'
import { Todo } from './todo';
import {ReactiveFormsModule} from '@angular/forms'
import { UrlResolver } from '@angular/compiler';
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'project';
  typed='';
  date=new Date();
  todoValue:string;
  todoValue1:string;
  nameval:string;
  dateval:string;
  
  list:Todo[];
  list2:[];
  email= new FormControl('');

  updateEmail(){
    this.email.setValue('test@testdomain.com')
  }
  ngOnInit(){
    this.list2=[];
    this.list=[];
    this.todoValue='';
    this.todoValue1='';
    this.nameval='';
    this.dateval;
  }
  addvalue()
  {
    if(this.todoValue!='')
    {
      const newItem:Todo={
        id:Date.now(),
        value:this.todoValue,
        isDone:false
    }
      this.list.push(newItem)
    }
    else{
      alert('should not be empty')
    }
    this.todoValue='';
  }
  addvalue1()
  {
    if(this.todoValue1!='')
    {
      const newItem:Todo={
        id:Date.now(),
        value:this.todoValue1,
        isDone:false
      
    }
      this.list.push(newItem)
    }
    this.todoValue1='';
  }
  deleteItem(id:number)
  {

    this.list=this.list.filter(item => item.id!=id);
  }
  check(){
    if(this.nameval=='' ){
      
      alert('starred fields sholud not be empty')
    }
    else{
      alert('tahnk you visit again')
    }
  }
}


