export interface Todo{
    id:number;
    value:string;
    isDone:boolean;
}