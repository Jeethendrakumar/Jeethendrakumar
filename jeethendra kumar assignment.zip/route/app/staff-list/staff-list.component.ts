import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-staff-list',
  template: `
    <p style="background-color:yellow">
      Iam the staff
    </p>
  `,
  styles: [
  ]
})
export class StaffListComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
