import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-dept-list',
  template: `
  
    <p style="background-color:tomato;">
      Iam a student
    </p>

  `,
  styles: [
  ]
})
export class DeptListComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
