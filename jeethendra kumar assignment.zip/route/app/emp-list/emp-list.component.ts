import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-emp-list',
  template: `
    <p style="background-color:pink;">
      Iam the Head of the department
    </p>
  `,
  styles: [
  ]
})
export class EmpListComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
