import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { DeptListComponent }  from './dept-list/dept-list.component'
import { EmpListComponent}  from './emp-list/emp-list.component'
import { StaffListComponent } from './staff-list/staff-list.component'
import { from } from 'rxjs';
const routes: Routes = [
  {path:'departments',component:DeptListComponent},
  {path:'employee',component:EmpListComponent},
  {path:'staff',component:StaffListComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
export const routingComponents = [DeptListComponent,EmpListComponent,StaffListComponent]
